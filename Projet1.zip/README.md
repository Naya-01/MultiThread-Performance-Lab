# MultiThread-Performance-Lab
Programmation multi-threadée et évaluation de performances 

## First Time   

``make``

python3 -m venv ./.venv

source ./.venv/bin/activate

pip install numpy 

pip install matplotlib

## Run perf

`./experiments.sh`


### For plots

`python3 plots.py`


